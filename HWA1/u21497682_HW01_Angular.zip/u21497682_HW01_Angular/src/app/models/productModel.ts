export interface product {
    product_ID: number;
    product_Name: string;
    product_Description: string;
    product_Price: number;
}